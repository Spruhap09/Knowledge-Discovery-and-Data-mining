import storage from 'redux-persist/lib/storage';

const persist = {
    key: 'root', 
    storage: storage,
    whitelist: ['collections', 'selection']
}

export default persist;