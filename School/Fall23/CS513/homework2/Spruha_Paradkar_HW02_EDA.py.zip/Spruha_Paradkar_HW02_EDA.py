import pandas as pd
#import file
# import numpy
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
breastCancer = pd.read_csv('/Users/spruhap/Downloads/breast-cancer-wisconsin.csv')

#preview data
print(breastCancer.head())

print("Part 1: Summarizing the data")
print()
print("Summary of Sample")

print("getting the missing values")
breastCancer2 = breastCancer.loc[breastCancer['F6'] != '?']
print(breastCancer2)
mean = breastCancer2['F6'].astype(int).mean()
# mean = int(math.ceil(mean))
print("the mean")
print(mean)

breastCancer["F6"].replace("?", str(mean), inplace=True)
breastCancer['F6'] = breastCancer["F6"].astype(float)

print(breastCancer["F1"].describe()) 
print(breastCancer["F2"].describe()) 
print(breastCancer["F3"].describe()) 
print(breastCancer["F4"].describe()) 
print(breastCancer["F5"].describe())
print(breastCancer["F6"].describe())
print(breastCancer["F7"].describe()) 
print(breastCancer["F8"].describe()) 
print(breastCancer["F9"].describe())
breastCancer['F6'] = breastCancer["F6"].astype(int)
print("the frequency table")
# print(breastCancer.value_counts(['F6', 'Class']))
print(breastCancer.groupby(['F6', 'Class']).size())

scatter_matrix(breastCancer, alpha=0.2, figsize=(12, 12), diagonal='hist')
plt.show()
# print(isinstance(breastCancer2, pd.DataFrame))
# print(isinstance(breastCancer, pd.DataFrame))

# print(len(nonMissingValues))
# missingValues = breastCancer.loc[breastCancer['F6'] == '?']

# print("The rows with missing values")
# print(missingValues)
# print("The length of the missing values")
# print(len(missingValues))

# breastCancer["F6"].replace("?", "6.545", inplace=True)

# print(breastCancer["F6"])
# print("bkkakak")
# print(breastCancer.loc[breastCancer['F6'] == '?'])


